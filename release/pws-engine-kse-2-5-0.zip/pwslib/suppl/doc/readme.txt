README for SUPPLEMENTS
======================

As of release 2-4-0 the package "pws-suppl-ftp.jar" is offered, which allows
FTP access to database files, both reading and writing. The supplement contains
class AbstractFTPAdapter implementing ApplicationAdapter plus external FTP 
handling software. 

LEGAL NOTICE!

This package contains software from Sauron Software named "ftp4j-1.7.2.jar" 
© Sauron Software 2007 - 2012. It is released under the LGPL license. If you
apply this supplement to works based on the PWSLIB library, your entire work 
also must conform to the LGPL license.

06. Nov. 2015

